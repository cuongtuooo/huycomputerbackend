### Các bước cần làm để chạy dự án NestJS

#### 1. Cài đặt thư viện với câu lệnh: npm i
#### 2. Chạy dự án với câu lệnh: npm run dev


=================
