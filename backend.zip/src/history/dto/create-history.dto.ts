export class CreateHistoryDto {}
